package com.atguigu.mybatisx.service;

import com.atguigu.mybatisx.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface UserService extends IService<User> {

}
