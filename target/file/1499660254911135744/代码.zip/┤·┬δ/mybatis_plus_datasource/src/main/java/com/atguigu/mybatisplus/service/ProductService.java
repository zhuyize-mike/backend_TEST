package com.atguigu.mybatisplus.service;

import com.atguigu.mybatisplus.pojo.Product;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * Date:2022/2/15
 * Author:ybc
 * Description:
 */
public interface ProductService extends IService<Product> {
}
