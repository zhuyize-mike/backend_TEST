package com.atguigu.mybatisplus.pojo;

import lombok.Data;

/**
 * Date:2022/2/15
 * Author:ybc
 * Description:
 */
@Data
public class Product {

    private Integer id;

    private String name;

    private Integer price;

    private Integer version;

}
